## Libicons  v3.0.19
##### 12/09/2019  

*Por Fabiano Rodrigues <fabiano.rodrigues@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-ctps-digital
    ico-mail-open
    ico-user-houglass
    ico-user-minus-c
    ```

## Libicons  v3.0.18
##### 10/07/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Ajustes no package.json

## Libicons  v3.0.17
##### 11/06/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-share
    ico-camera-switch
    ```

## Libicons  v3.0.16
##### 13/05/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-user-empty-doc
    ico-user-time
    ico-vacations
    ```

## Libicons  v3.0.15
##### 04/04/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    letter-minus
    letter-plus
    ```

## Libicons  v3.0.14
##### 26/02/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Ajustes no build

## Libicons  v3.0.13
##### 20/02/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novo ícone**:

    ```
    ico-arrows_transfer_vertical
    ```

## Libicons  v3.0.12
##### 17/01/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-lamp
    ico-thought-cloud
    ```

## Libicons  v3.0.11
##### 11/01/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novo ícone**:

    ```
    ico-man-magnifier
    ```

## Libicons  v3.0.10
##### 08/01/2019  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-car
    ico-doc-ci
    ```

## Libicons  v3.0.9
##### 20/11/2018  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Ajustes no build

## Libicons  v3.0.8
##### 09/11/2018  

*Por José Rogério Filho <joserogerio.filho@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-at-dot
    ico-baby-stroller
	ico-list
	ico-list-condensed
	ico-octothorpe
	ico-processor
	ico-ram
	ico-smile
	ico-smile-plus
	ico-sort
	ico-sort-alphabetical
	ico-sort-asc
	ico-sort-desc
    ```
	
2. Correção da grid dos seguintes ícones:

    ```
    ico-corn
	ico-doctor-back
	ico-hook
	ico-qr-code
	ico-arrow-curve-left
	ico-arrow-curve-right
	ico-money-bag-back
	ico-money-bag-next
	ico-user-back
	ico-spinner
	ico-chat
    ```

## Libicons  v3.0.7
##### 05/03/2018  

*Por Tiago Freire <tiago.freire@dataprev.gov.br>*

1. Ajustes no build

## Libicons  v3.0.6
##### 05/03/2018  

*Por Décio Benício <decio.santos@dataprev.gov.br>, Fabiano Rodrigues <fabiano.rodrigues@dataprev.gov.br>, Jose Rogerio Bezerra Barbosa Filho <joserogerio.filho@dataprev.gov.br> e Letícia Hartmann <leticia.hartmann@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-calc
    ico-inv-commas
    ico-inv-commas-end
    ico-eraser
    ```

## Libicons  v3.0.5
##### 01/11/2017  

*Por Décio Benício <decio.santos@dataprev.gov.br>, Fabiano Rodrigues <fabiano.rodrigues@dataprev.gov.br>, Jose Rogerio Bezerra Barbosa Filho <joserogerio.filho@dataprev.gov.br> e Letícia Hartmann <leticia.hartmann@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-cadunico
    ico-miner-car
    ico-worker-boss
    ico-worker
    ```

2. Ajuste em desenhos de ícones 

    ```
    ico-docs-layer
    ico-docs
    ico-school-cap
    ico-docs-archive
    ico-docs-drawer
    ```

## Libicons  v3.0.4
##### 03/07/2017  

*Por Eder Nogueira <eder.nogueira@dataprev.gov.br> e Tiago Freire <tiago.freire@dataprev.gov.br>*

1. Configuração para minificação do style.css
2. Instruções de minificação no README

## Libicons  v3.0.3
##### 02/06/2017  

*Por Tiago Freire (Atualização) <tiago.freire@dataprev.gov.br>*

1. Configuração para empacotamento no Maven
2. Instruções de instalação via Maven e Bower no README

## Libicons  v3.0.2 
##### 20/03/2017  

*Por Décio Benício (Atualização) <decio.santos@dataprev.gov.br>, e Letícia Hartmann (Design) <leticia.hartmann@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-corn
    ico-doctor-back
    ico-hook
    
    ```

## Libicons  v3.0.1 
##### 20/03/2017  

*Por Décio Benício <decio.santos@dataprev.gov.br>, Fabiano Rodrigues <fabiano.rodrigues@dataprev.gov.br> e Letícia Hartmann <leticia.hartmann@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-qr-code
    ico-arrow-curve-left
    ico-arrow-curve-right
    ico-money-bag-back
    ico-money-bag-next
    ico-user-back
    
    ```

## Libicons  v3.0.0 
##### 20/03/2017  

*Por Décio Benício Costa dos Santos <decio.santos@dataprev.gov.br>*

1. Redesign da biblioteca para ícones em outline

2. Adição de **novos ícones**:

    ```
    ico-chat
    ico-menu
    ico-tools
    ico-filter
    ico-doc-empty
    
    ```

## Libicons v2.9.0
##### 28/12/2016

*Por Danilo de Sousa <danilo.sousa@dataprev.gov.br>*

1. Adição de 18 **novos ícones**:

    ```
    ico-carret-up
    ico-carret-down
    ico-carret-right
    ico-carret-left
    ico-up-c-double
    ico-left-c-double
    ico-clipboard-search
    ico-expand
    ico-hourglass-plus
    ico-hourglass-minus
    ico_lets-letter-small
    ico-pacifier
    ico-shield-user
    ico-star
    ico-star-empty
    ico-ticket
    ico-tickets
    ico-database
    
    ```
    
2. Melhoria de desenho de 26 ícones:

    ```
    ico-building-arrow
    ico-cancel
    ico-cancel-circle
    ico-check-circle
    ico-download
    ico-hammer-base
    ico-hammer-base-minus
    ico-hammer-base-plus
    ico-link-minus
    ico-link-plus
    ico-minus
    ico-plus
    ico-money
    ico-money-bag
    ico-money-c
    ico-money-pencil
    ico-pj-check
    ico-print
    ico-process-check
    ico-seal-minus
    ico-seal-plus
    ico-seals
    ico-shakehand
    ico-spinner
    ico-trach-can-recover
    ico-upload
    
    ```

## Libicons v2.8.2
#### 16/11/2016

*Por Décio Benício <decio.santos@dataprev.gov.br>*

1. Adição do ícone de indígena

    ```
    ico-indian
    
    ```
    
2. Melhoria de desenho do ícone de spiner:

    ```
    ico-spinner
    
    ```


## Libicons v2.8.1
#### 28/10/2016 
*Por Décio Benício <decio.santos@dataprev.gov.br>*

1. Melhoria de desenho do ícone:

    ```
    ico-handshake
    
    ```

## Libicons v2.8 
#### 05/10/2016

*Por Décio Benício <decio.santos@dataprev.gov.br>*

1. Atualização do repositório: disponibilização de versões em LESS e SASS da biblioteca
2. Atualização do README
3. Adição de novo ícone:

    ```
    ico-card
    
    ```

#### 19/08/2016

*Por Tiago Freire <tiago.freire@dataprev.gov.br>*

1. Correção dos links showcase-new para showcase-inss
2. Correção do link do setor no webdatafone
3. Correção do link para o projeto do showcase no www-scm

## Libicons v2.7 
##### 14/04/2016  

*Por Danilo de Sousa <danilo.sousa@dataprev.gov.br>*

1. Adição de **novos ícones**:

    ```
    ico-seal-plus
    ico-seal-minus
    ico-seals
    ico-handshake
    ico-money-pencil
    ico-download
    ico-upload
    ico-check-circle
    ico-cancel-circle
    ico-building-arrow
    ico-doc-download
    ico-doc-book
    ico-hammer-base
    ico-hammer-base-plus
    ico-hammer-base-minus
    ico-pj-check
    ico-process-check
    ico-trash-can-recover
    ico-link-plus
    ico-link-minus
    ```

## Libicons v2.6 
##### 06/04/2016  

*Por Decio Benicio <decio.santos@dataprev.gov.br>, <deciotgr@gmail.com>*

1. Adição de **novos ícones**:

    ```
    ico-pin
    ico-route
    ```

## Libicons v2.5 
##### 23/03/2016  

*Por Decio Benicio <decio.santos@dataprev.gov.br>, <deciotgr@gmail.com>*

1. Adição de **novos ícones**:
```
ico-doc-thumb-down
ico-doc-thumb-up
ico-arrow-triple-left
ico-school-cap
ico-doc-info
ico-doc-check-ci
ico-clipboard-man
ico-doc-refresh-29
```

2. Melhoria estética dos **ícones**:
```
ico-doc-refresh
```


## Libicons v2.4 
##### 05/02/2016  

*Por Decio Benicio <decio.santos@dataprev.gov.br>, <deciotgr@gmail.com>, Edemar Santos <edemar.santos@dataprev.gov.br>, <edemarsantos@gmail.com>* e colegas :)

1. Adição de **novos ícones**:
```
ico-thumb-down
ico-thumb-up
```

2. Melhoria estética dos **ícones**:
```
ico-bag-medical
ico-more-horizontal
ico-more-vertical
```



## Libicons v2.3 
##### 28/09/2015  

*Por Decio Benicio <decio.santos@inss.gov.br>, <deciotgr@gmail.com>, Edemar Santos <edemar.santos@dataprev.gov.br>, <edemarsantos@gmail.com>*

1. Adição de **novos ícones**:
```
ico-jail --> Períodos de reclusão
ico-badge-militar --> Períodos de serviço militar
```

2. Melhoria estética dos **ícones**:
```
ico-bag-medical
ico-check
```

3. Ajuste da URL da demonstração online dos ícones na FAQ #1 (de _showcase_ para _showcase-new_).

4. Adição das perguntas 13 e 14 na FAQ.

5. Ajustes no *Procedimento para criação/atualização da Libicons*.

6. Remoção de URL's quebradas.



## Libicons v2.2 
##### 25/05/2015  

*Por Decio Benicio <decio.santos@inss.gov.br>, <deciotgr@gmail.com>, Edemar Santos <edemar.santos@dataprev.gov.br>, <edemarsantos@gmail.com>*

1. Adição de **novos ícones** usados em componentes de paginação:
```
ico-left-double-c \e6a0
ico-right-double-c \e6a1
```
Estes devem ser usados em associação aos já existentes:
```
ico-left-c \e68d
ico-right-c \e68e
```

2. Normalização do **grid size** (64x64 pixels) dos novos ícones no IcoMoon.



## Libicons v2.1 
##### 25/05/2015  

*Por Tiago Freire <tiago.freire@dataprev.gov.br>, Edemar Santos <edemar.santos@dataprev.gov.br>, <edemarsantos@gmail.com>*

1. Adição de **novos ícones** usados em componentes de paginação:
```
ico-triangle-left2 \e614
ico-triangle-right2 \e69d
ico-triangle-first \e69e
ico-triangle-last \e69f
```

2. Alteração de `libicons.less` para respeitar a correta **herança de pseudo-elementos** `:before`.  



## Libicons v2.0 
##### 16/04/2015  

*Por Decio Benicio <decio.santos@inss.gov.br>, <deciotgr@gmail.com>, Edemar Santos <edemar.santos@dataprev.gov.br>, <edemarsantos@gmail.com>*

1. Alteração na **nomenclatura** da grande maioria dos ícones, seguindo as regras:
    * Relacionar nomes ao seu desenho ou aceitação mundial (não mais à sua função dentro do contexto da aplicação que o usa).
    * Usar nomes em idioma inglês (largamente aceito no contexto de desenvolvimento de software).
    * Usar sufixos quando aplicável. Exemplos: `-c` (circle), `-t` (triangle), `-s` (square), `-minus` (menos), `-plus` (mais).
    * Usar nomes de domínio para logomarcas corporativas (`ico-br-gov-mps` onde era `ico-prevlogo`).

2. Alteração na **forma e posicionamento** de alguns ícones;

3. Adição de **novos ícones**:
```
ico-airplane
ico-arrow-down
ico-arrow-up
ico-bell-minus
ico-bell-plus
ico-counterclockwise
ico-doc-alert
ico-doc-arrow-right
ico-doc-certificate
ico-doc-check
ico-doc-question
ico-folder
ico-hourglass-end
ico-hourglass-start
ico-index-card
ico-left-c
ico-letter
ico-lion-face
ico-money-bag
ico-more-vertical
ico-right-c
ico-serving-man
ico-ship
ico-stethoscope
ico-text-size
ico-unlink
ico-user-c
ico-user-minus
```

4. **Remoção de alguns ícones**, como os de produtos (`ico-cnis` e `ico-sibe`):
```
ico-calcular
ico-chrome
ico-cnis
ico-css3
ico-e-req
ico-firefox
ico-html5
ico-ie
ico-opera
ico-safari
ico-sibe
ico-tag
ico-tags
ico-trofeu
```

5. **Removido diretório** `/showcase/ie7` (referente a suporte para browsers Internet Explorer 6 e 7);

6. Adicionada **fonte [WOFF](http://en.wikipedia.org/wiki/Web_Open_Font_Format) inline** (nos arquivos `/libicons.less` e `/showcase/style.css`). 



## Libicons v1.0 
##### 13/11/2014  

*Por Decio Benicio <decio.santos@inss.gov.br>, <deciotgr@gmail.com>*

Criação inicial.
* As classes CSS relacionadas são prefixadas por "`ico-`", como em "`.ico-radio`".
* Adicionada fonte *TTF (TrueType)* inline.

