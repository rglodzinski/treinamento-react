# Gerar Nova Versão da Libicons
<br/>

## Pré-Condições
### 1. Instalar o [Git](https://git-scm.com/);
### 2. Instalar o [Node/NPM](https://www.npmjs.com/get-npm) para uso do minify;
### 3. Instalar o pacote NPM minify executando o comando `npm i minify -g` num terminal
<br/>

## Passo a Passo
<br/>

### 1. Baixe a versão mais recente da libicons;
Abra um terminal git na sua máquina local e clone o repositório a biblioteca usando o comando `git clone git@www-scm.prevnet:copd/libicons.git`.  ATENÇÃO: é necessário estar autenticado no GitLab, bastando entrar na página do [projeto](https://www-scm.prevnet/copd/libicons) em algum navegador e logar-se usando as credenciais do LDAP.
<br/><br/>
 
| Abrindo um terminal Git no Windows | Executando o comando de clonagem de repositório | Repositório copiado para a máquina local |
| :------: | :------: | :------: |
| ![1_git_bash_here](/uploads/c4a9dbd4c680a6eeff15fd73d3688162/1_git_bash_here.png) | ![2_git_clone](/uploads/a287fb1abecd0712752e752ef8e3a69a/2_git_clone.PNG) | ![3_git_clone_resultado](/uploads/1174893573b25aa64e474e54c1c2d84e/3_git_clone_resultado.PNG) |
<br/><br/>

### 2. Importe a libicons no webapp [IcoMoon](https://icomoon.io/app/#/projects);
O IcoMoon App é um webapp de manipulação de bibliotecas de ícones. Na tela de [gerência de projetos](https://icomoon.io/app/#/projects) importe a biblioteca libicons baixada no passo anterior selecionando o arquivo `selection.json` no diretório.
<br/><br/>
 
| Importando a libicons no IcoMoon App | Abrindo a biblioteca para manipulação de ícones |Biblioteca libicons carregada no IcoMoon App |
| :------: | :------: | :------: |
| ![4_icomoon_projects_EDITED](/uploads/331ec0befe6b91d099cc5db756ccbadd/4_icomoon_projects_EDITED.png) | ![5_icomoon_project_loaded_EDITED](/uploads/933d711c38c86cd4215074dc26a6ee6c/5_icomoon_project_loaded_EDITED.png) | ![6_icomoon_project_opened](/uploads/ab16354aed3761f58474e998a325d5e1/6_icomoon_project_opened.png) |
<br/><br/>

### 3. Adicione os novos ícones à biblioteca no IcoMoon App;
Clique no menu superior direito e selecione a opção "Import to set". Selecione os arquivos SVG ods ícones a serem adicionados na janela de diálogo que irá surgir. Os ícones aparecerão no ínicio da sua biblioteca. Será necessário movê-los para o final da lista para que o código dos ícones já existente não sejam alterados. Para isso, selecione a ferramenta mover na parte superior da aplicação e mova os ícones, um por um, até o final da biblioteca.
<br/><br/>
 
| Clicar em "Import to Set" e selecionar os SVGs dos novos ícones | Selecionar a ferramenta "Mover" | Arrastar os novos ícones até o final da biblioteca |
| :------: | :------: | :------: |
| ![7_icomoon_import_to_set_EDITED](/uploads/22be4180e99a8c11a0a8c78769406432/7_icomoon_import_to_set_EDITED.png) | ![8_icomoon_icon_imported_EDITED](/uploads/11ccd1c9e19b976ad5193be6279dd10d/8_icomoon_icon_imported_EDITED.png) | ![9_icomoon_move_to_final_EDITED](/uploads/5e348e2547e7b390cc7a6c5742d039ac/9_icomoon_move_to_final_EDITED.png) |
<br/><br/>

### 4. Edite as propriedades dos novos ícones;
Para cada novo ícone adicionado, edite suas propriedades de "Grid", "Tags" e "Names". A grade (grid) deve ser de 64 enquanto os campos de "Tags" e "Names" devem conter uma descrição sucinta do ícone em inglês usando hífens para representar espaços em branco. Ex.: share, camera-switch, trash-can-recover, etc.
<br/><br/>
 
| Clicar na ferramenta "Edit" e depois clique no novo ícone | Insira o valor 64 para "Grid" e uma breve descrição em inglês para "Tags" e "Names" |
| :------: | :------: |
| ![10_icomoon_edit_icon_EDITED](/uploads/14b385f3f1e8ae6ceac4c75869e5d8a5/10_icomoon_edit_icon_EDITED.png) | ![11_icomoon_edit_icon_dialog](/uploads/3222ee0ff4100987898f7eda83cc32f7/11_icomoon_edit_icon_dialog.png) |
<br/><br/>

### 5. Selecionar todos os ícones e clicar em "Generate Font";
Chegou a hora de gerar uma nova versão da fonte libicons. Para isso, é necessário selecionar todos os ícones (incluindo os que acabaram de ser incluídos). O jeito mais rápido para isso é clicar no menu da parte superior direita da página e selecionar a opção "Select all". Em seguida, clique na aba "Generate Font". Antes de fazer o download do projeto, é necessário editar suas propriedades. Clique no ícone de engranagem para abrir as propriedades da fonte.
<br/><br/>
 
| Selecionar a opção "Select all" no menu da biblioteca | Clicar no ícone de engragem para abrir as propriedades da fonte |
| :------: | :------: |
| ![12_icomoon_select_all_EDITED](/uploads/fdc248daa24389d2f228bab5e9471171/12_icomoon_select_all_EDITED.png) | ![13_icomoon_font_EDITED](/uploads/2b2112056536f6e645d30ace23120bf9/13_icomoon_font_EDITED.png) |
<br/><br/>

### 6. Garanta que os metadados estejam corretos e incremente o número da versão;
Na janela de diálogo das preferências da fonte é possível visualizar os metadados. Eles já estarão preenchidos não devendo ser alterados. Visualize as imagens abaixo para conferir se eles foram carregados corretamente. Além disso, é necessário que se incremente o número da versão da biblioteca no final das preferências. Caso seja uma mudança pequena (adição de ícones ou correção de build) que não acarretará em quebra de build caso a bibilioteca seja atualizada por projetos que utilizam a versão anterior, basta incrementar o valor "Minor" da versão.
<br/><br/>
 
| Confira se os metadados foram carregados corretamente | Incremente o número "Minor" da versão atual |
| :------: | :------: |
| ![14_icomoon_font_preferences_1](/uploads/0a3cfde7c5f15ee59125f7c23ae56d9b/14_icomoon_font_preferences_1.png) | ![15_icomoon_font_preferences_2_EDITED](/uploads/ab6f580293a452dcb5369a1bf4ca54af/15_icomoon_font_preferences_2_EDITED.png) |
<br/><br/>

### 7. Exporte o projeto de fonte e os substitua pelos arquivos da versão atual;
Clique em "Download" para baixar um arquivo zipado do projeto de fonte contendo os novos ícones. Em seguida, extraia todos os arquivos zipados para o diretório `libicons\libicons` substituindo os arquivos originais.
<br/><br/>
 
| Faça download do projeto da fonte | Extraia os arquivos na sua cópia local da libicons substituindo os originais |
| :------: | :------: |
| ![16_icomoon_font_download_EDITED](/uploads/37381561691aa53b69cbcde24e23d118/16_icomoon_font_download_EDITED.png) | ![17_replace_files](/uploads/a69bed17bb224f8db3e92d7446846c7e/17_replace_files.png) |
<br/><br/>

### 8. Excluir o arquivo de fonte .EOT e suas referências nas folhas de estilo;
Delte o arquivo ´libicons.eot´ do diretório ´libicons/libicons/fonts´. Em seguida, remova sua referência do ´@font-face´ dos arquivos ´style.css´ e ´style.scss´ no diretório ´libicons/libicons´.
<br/><br/>
 
| Exclua o arquivo ´libicons.eot´ | Delete suas referências do ´@font-face´ das folhas de estilo | O CSS resultante deverá possuir apenas o atributo  ´src´ dos arquivos TTF, WOFF e SVG |
| :------: | :------: | :------: |
| ![18_delete_font_eot_EDITED](/uploads/c7505dc72478351a8c80165fe988de5d/18_delete_font_eot_EDITED.png) | ![19_delete_eot_references_EDITED](/uploads/bcaea8f5411d46fac8b24bacbfbd9965/19_delete_eot_references_EDITED.png) | ![20_stylesheets_modified](/uploads/b54443ed64f9d24f1983a0fb48e63dd9/20_stylesheets_modified.png) |
<br/><br/>

### 9. Atualizar os arquivos `pom.xml` e `CHANGELOG.md` e gerar o arquivo `style.min.css`;
Edite o arquivo `pom.xml` e edite o número da versão para o mesmo incremento que foi colocado nos metadados no passo 6. Edite o arquivo CHANGELOG.md e insira um bloco de versão informando a ação feira (adição de novos ícones, correção de build, etc) semelhante a entradas anteriores. Para gerar o arquivo `style.min.css`, abra um terminal no diretório `libicons/libicons` e execute o comando `node minify style.css > style.min.css`.
<br/><br/>
 
| Atualize a versão do arquivo `pom.xml` | Insira uma nova entrada no arquivo CHANGELOG.md | Gere o arquivo minificado `style.min.css` |
| :------: | :------: | :------: |
| ![21_pom_xml_EDITED](/uploads/6dc70f841fbc93063bbf426c594a5257/21_pom_xml_EDITED.png) | ![22_changelog_md_EDITED](/uploads/6d7eb91b4f59f948b8f4a33dfdd00672/22_changelog_md_EDITED.png) | ![23_minify_style_css](/uploads/d87cbe8ec50559a71934339cdb2882dd/23_minify_style_css.png) |
<br/><br/>

### 10. Atualizar os arquivos `pom.xml` e `CHANGELOG.md` e gerar o arquivo `style.min.css`;
Edite o arquivo `pom.xml` e edite o número da versão para o mesmo incremento que foi colocado nos metadados no passo 6. Edite o arquivo CHANGELOG.md e insira um bloco de versão informando a ação feira (adição de novos ícones, correção de build, etc) semelhante a entradas anteriores. Para gerar o arquivo `style.min.css`, abra um terminal no diretório `libicons/libicons` e execute o comando `node minify style.css > style.min.css`.
<br/><br/>
 
| Atualize a versão do arquivo `pom.xml` | Insira uma nova entrada no arquivo CHANGELOG.md | Gere o arquivo minificado `style.min.css` |
| :------: | :------: | :------: |
| ![21_pom_xml_EDITED](/uploads/6dc70f841fbc93063bbf426c594a5257/21_pom_xml_EDITED.png) | ![22_changelog_md_EDITED](/uploads/6d7eb91b4f59f948b8f4a33dfdd00672/22_changelog_md_EDITED.png) | ![23_minify_style_css](/uploads/d87cbe8ec50559a71934339cdb2882dd/23_minify_style_css.png) |
<br/><br/>


### 11. Subir uma nova versão para o repositório Git;
Abra um terminal Git no diretório raiz do projeto (`libicons`) e execute o comando `git add --all`. Em seguida, execute o comando `git commit -m "Breve descricao das alteracoes"`. Por último, execute o comando `git push` para enviar as alterações ao repositório online e subir suas alterações locais.
<br/><br/>
 
| `git add --all` | `git commit -m "Breve descricao das alteracoes"` | `git push` |
| :------: | :------: | :------: |
| ![24_git_add](/uploads/c2dd2cdcce66c03e41d713937c0a2a94/24_git_add.png) | ![25_git_commit](/uploads/1aad540d8c81ce4f86b9ced274983bef/25_git_commit.png) | ![26_git_push](/uploads/80fd53b0f8ce5cf7c27cc3e3cdfadad1/26_git_push.png) |
<br/><br/>


### 12. Criar uma tag no GitLab;
Entre na página do repositório da libicons no GitLab e clique na aba "Tags". Na página de tags, clique no botão "New tag". Entre com o número da tag no campo "Tag name" e copie o bloco de texto da nova versão exatamente como foi escrito no CHANGELOG.md no campo "Release notes". Por fim, clique em "Create tag".
<br/><br/>
 
| Acessar a página do projeto | Acessar a página de Tags | Criar uma nova Tag |
| :------: | :------: | :------: |
| ![27_gitlab_tags_EDITED](/uploads/c7252f7d98fa7b3fdb461c3efa2e2356/27_gitlab_tags_EDITED.png) | ![28_gitlab_newtag_EDITED](/uploads/d52ebcdbbb7852087248f106d8bfb6e9/28_gitlab_newtag_EDITED.png) | ![29_gitlab_tag_fileds](/uploads/1cda0c7afeec3855cb5fc2c53ab8ba9a/29_gitlab_tag_fileds.png) |
<br/><br/>