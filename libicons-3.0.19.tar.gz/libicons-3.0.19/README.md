# Libicons

---

## A biblioteca de ícones para aplicações desenvolvidas pela Dataprev

A [libicons](http://www-scm.prevnet/copd/libicons/tree/master) é uma biblioteca de ícones de criação própria, totalmente voltada para a realidade das aplicações desenvolvidas pela Dataprev. Reúne um conjunto de símbolos que podem ser utilizados para ilustrar estados, ações e funcionalidades do sistema.

![Arte de Introdução](showcase/assets/images/intro-art.jpg)


---

### Gerando versão da libicons (para os mantenedores deste projeto)
```bash
npm install && npm run minify && mvn clean install deploy
```

### Utilização nos projetos
##### Via Maven (disponível a partir da versão 3.0.3)
*pom.xml*
```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-dependency-plugin</artifactId>
            <version>2.8</version>
            <executions>
                <execution>
                    <id>install-libicons</id>
                    <phase>process-resources</phase>
                    <goals>
                        <goal>unpack</goal>
                    </goals>
                    <configuration>
                        <artifactItems>
                            <artifactItem>
                                <groupId>br.gov.dataprev.themes</groupId>
                                <artifactId>libicons</artifactId>
                                <version> <!-- Inserir versão da libicons desejada --> </version>
                                <!-- A linha abaixo pode variar dependendo do projeto pois em alguns o ${project.version} não é incluído no nome do pacote. -->
                                <outputDirectory>${project.build.directory}/${project.artifactId}-${project.version}/public/libicons</outputDirectory>
                                <includes>libicons/**/*,legado/**/*</includes>
                            </artifactItem>
                        </artifactItems>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```
*Declaração do css*
```css
<link href="<CONTEXT PATH DA APLICAÇÃO>/public/libicons/libicons/style.css" rel="stylesheet" type="text/css" />
```

##### Via Bower (framework SPA)
*bower.json*
```javascript
"dependencies": {
    "libicons": "https://www-scm.prevnet/copd/libicons.git#^<Inserir versão da libicons desejada>"
}
```
*Declaração do css*
```css
<link href="<CONTEXT PATH DA APLICAÇÃO>/bower_components/libicons/libicons/style.css" rel="stylesheet" type="text/css" />
```

### FAQ - Perguntas frequentes

1. Cadê a **demonstração?**

    ### [Veja online no Showcase!](http://v221d047.nuvemdtp/public/showcase-libicons/)

2. **Falta o ícone** *< preencha aqui >*. O que fazer? (Ou *de como solicitar a inclusão de um ícone*)

    Leia a resposta da próxima pergunta :)
    
3. **Posso usar o ícone *ico-XIS* para representar "XPTO"** dentro do meu sistema? Por exemplo, usar o ícone *`ico-moeda-c`* para representar *"Adicionar uma mesada ao dependente menor de 12 anos no Requerimento de BI"* dentro do sistema SIBE?
    
    Cada ícone deve possuir um significado claro e único em todos os sistemas desenvolvidos na casa, para não confundir o usuário.  
    A COPD está centralizando esta relação ícone-sistema-significado. [Faça sua sugestão aqui no projeto](https://www-scm.prevnet/copd/libicons) ou entre em contato com a [COPD](http://www-datafone.prevnet/pesquisas/porsetor.php?idsetor=1283).

4. Quero colocar o **logotipo** do meu produto. Posso?

    A definição do logotipo/marca deve partir do cliente. No caso de haver um, **NÃO** deve constar na Libicons: adicione-o como uma imagem no sistema.

5. Como **adicionar a Libicons** em meu projeto?

    Baixe o [Repositório](https://www-scm.prevnet/copd/libicons).

6. Posso **alterar os arquivos** desta biblioteca em meu projeto?

    **NÃO!** Esta biblioteca sofre alterações que devem ser refletidas em todos os produtos. Personalizações não são aceitas porque dificultam esta replicação.

7. O que deve estar no **ambiente de produção**?

    Apenas os arquivos `style.css*` (gerado pelo processamento dos arquivos LESS ou SASS, vide pergunta abaixo) e os arquivos das fontes da libicons (pasta /fonts).

8. E estas pastas **`libicons-less / libicons-sass`?**

    São os locais onde foram disponibilizados os arquivos em less ou sass, os arquivos de estilos (style.css) e as fontes da Libicons (/fonts).

<!--    Na prática vira o arquivo `libicons.css`. É que [LESS](http://lesscss.org/) acrescenta funcionalidades ao [CSS](http://www.w3.org/Style/CSS/) que implementam herança de classes e facilitam a vida dos designers (por exemplo, o ajuste das cores de ícones marcados como sucesso, informação, alerta e perigo).-->

9. Vale propor **ícones coloridos?**

    Os ícones propostos devem estar de acordo com o *Guia de Identidade Visual* do produto.  
    Tipicamente mantém-se o uso **monocromático** (somente branco, preto e um tom de cinza). Isto facilita:  
    
    *(a)* a compreensão por pessoas com alguma deficiência visual,  
    *(b)* o uso de alto contraste e  
    *(c)* variações cromáticas (como as citadas na pergunta acima ou advindas de mudanças no tema visual).

10. Como aumentar ou diminuir o **tamanho do ícone** apresentado?

    Usando classes CSS próprias para isto.  No caso do Showcase, da mesma forma que no *Font Awesome* (fa-lg, fa-2x, fa-3x, fa-4x, fa-5x).

11. **Cadê meus ícones?** Ou: que *"ótimo"!* Vocês *arrebentaram* com minha aplicação >:-( 

    Provavelmente você está sofrendo da *Síndrome de Mudança do Major Number*:  
    a versão 2.0 trocou a nomenclatura portuguesa "funcional" para a inglesa "morfológica".  
    Há uma ferramenta que altera os nomes dos ícones no seu código-fonte. Procure a COPD. 
    Lembre-se que há ícones SEM correspondência...

12. **Meu cliente não é o INSS.** O cliente <[preencha aqui](http://portal.dataprev.gov.br/2009/07/27/clientes-da-dataprev/)> pode usar esta biblioteca?

    Boa pergunta!
    
    **Sim!** Simples assim.
    
<!--    Apesar da [SECOM](http://www.secom.gov.br/) (Secretaria de Comunicação Social do Governo Federal) estabelecer algumas diretrizes, pensamos que cada cliente deve possuir sua biblioteca de ícones independente. [Fale conosco!](http://www-datafone.prevnet/pesquisas/porsetor.php?idsetor=1186)-->

13. Por que não usar [Font Awesome](https://fortawesome.github.io/Font-Awesome/) ou outra fonte gratuita?

    Usar uma única fonte de ícones reduz a quantidade de bytes e o  tempo de carga da página. A ideia também é ter controle do uso dos ícones (vide resposta à pergunta 3). Sugira que ícones adicionar!

14. Qual é a forma de **licenciamento** da Libicons?

    De uso livre.

-------------------------------------------------------------------------------


### Correspondência entre ícones antigos e novos
libicons-1.0 ↓ | libicons-2.0
-------------- | ------------
ico-abrirreq | ico-docs-drawer
ico-add-usuario | ico-user-plus
ico-adicionar | ico-plus
ico-agendar | ico-calendar
ico-ajuda | ico-help-c
ico-alerta-t | ico-alert-t
ico-alterar | ico-pencil
ico-ampulheta | ico-hourglass
ico-analisar | ico-doc-magnifier
ico-anexo | ico-clip
ico-arquivamento | ico-docs-archive
ico-atividades | ico-truck
ico-atualizacao | ico-doc-refresh
ico-avancar | ico-arrow-right
ico-bandeira | ico-flag
ico-biblioteca | ico-building-greek
ico-binoculos | ico-binoculars
ico-bloquear | ico-lock
ico-brilho | ico-brightness
ico-brilho-contrast | ico-contrast
ico-bug | ico-bug
ico-cadrodas | ico-wheelchair
ico-camera | ico-camera
ico-cancel-detalhar | ico-eye-no
ico-cancelar | ico-cancel
ico-cancelar-agenda | ico-calendar-empty
ico-caret-baixo | ico-triangle-down
ico-caret-cima | ico-triangle-up
ico-caret-direita | ico-triangle-right
ico-caret-esquerda | ico-triangle-left
ico-celular | ico-smartphone
ico-chave | ico-key
ico-checkbox-checked | ico-check
ico-checkbox-partial | ico-check-mid
ico-checkbox-unchecked | ico-uncheck
ico-cifrao | ico-money
ico-comprovar | ico-seal
ico-conf | ico-gear
ico-confirmar | ico-confirm
ico-contraste | ico-black-white-c
ico-copiar | ico-doc-copy
ico-css | ico-doc-braces
ico-dashboard | ico-gauge
ico-desbloquear | ico-unlock
ico-detalhar | ico-eye
ico-doc | ico-doc-list
ico-docadicionar | ico-doc-plus
ico-docs | ico-docs
ico-docsubtrair | ico-doc-minus
ico-download | ico-cloud-down
ico-elo | ico-link
ico-email | ico-mail
ico-entrar | ico-door-in
ico-esconder | ico-up-c
ico-escudo | ico-shield
ico-excel | ico-doc-sheet
ico-exclamacao | ico-alert
ico-excluir | ico-trash-can
ico-exigencias | ico-megaphone
ico-filme | ico-video
ico-filtro | ico-funnel
ico-fone | ico-phone
ico-generica | ico-more-horizontal
ico-graf | ico-graph-line
ico-historico | ico-timemachine
ico-home | ico-house
ico-homem | ico-man
ico-homologar | ico-stamp
ico-imagem | ico-image
ico-imprimir | ico-print
ico-info | ico-info-c
ico-info-n | ico-info
ico-mala | ico-bag
ico-marca | ico-bookmark
ico-marcas | ico-bookmarks
ico-martelo | ico-hammer
ico-moeda | ico-money-c
ico-mostrar | ico-down-c
ico-mulher | ico-woman
ico-notificacao | ico-alert-c
ico-nuvem | ico-cloud
ico-pasta | ico-folder-open
ico-pdf | ico-doc-pdf
ico-pendencias | ico-bell
ico-perfil-usuario | ico-user-profile
ico-permissao | ico-traffic-light
ico-pesquisar | ico-magnifier
ico-pilha | ico-docs-layer
ico-pizza | ico-graph-pizza
ico-plugin | ico-plug
ico-powerpoint | ico-doc-presentation
ico-predio | ico-building
ico-prevlogo | ico-br-gov-mps
ico-radio-checked | ico-radio
ico-radio-unchecked | ico-unradio
ico-raio | ico-ray
ico-relogio | ico-clock
ico-req-alterar | ico-doc-pencil
ico-resumir | ico-clipboard-check
ico-sair | ico-door-out
ico-salvar | ico-floppy-disk
ico-somatorio | ico-sigma
ico-spinner | ico-spinner
ico-subtrair | ico-minus
ico-tablet | ico-tablet
ico-teclado | ico-keyboard
ico-tela | ico-monitor
ico-terminal | ico-terminal
ico-terra | ico-world
ico-transferencia | ico-transfer
ico-trator | ico-tractor
ico-upload | ico-cloud-up
ico-usuario | ico-user
ico-usuarios | ico-users
ico-voltar | ico-arrow-left
ico-xml | ico-doc-code
ico-zip | ico-doc-zip


-------------------------------------------------------------------------------


### Tabela completa dos ícones (Ordem alfabética)

Inclui códigos Unicode e comparativo com a Libicons versão 1.0.

Sugiro evitar usar os códigos Unicode, mas eis um exemplo de uso:
~~~css
  div.alert.alert-info:before {
    content: "\e64c";
  }
~~~

libicons-2.9.1 ↓ | unicode-2.9.1 | libicons-1.0 | unicode-1.0 
-------------- | ------- | ------------ | ------- 
-- | -- | ico-calcular | \e61c
-- | -- | ico-chrome | \e63e
-- | -- | ico-cnis | \e666
-- | -- | ico-css3 | \e63d
-- | -- | ico-e-req | \e62a
-- | -- | ico-firefox | \e63f
-- | -- | ico-html5 | \e63c
-- | -- | ico-ie | \e640
-- | -- | ico-opera | \e641
-- | -- | ico-safari | \e642
-- | -- | ico-sibe | \e667
-- | -- | ico-tag | \e64a
-- | -- | ico-tags | \e64b
-- | -- | ico-trofeu | \e635
ico-airplane | \e626 | -- | --
ico-alert | \e64b | ico-exclamacao | \f12a
ico-alert-c | \e649 | ico-notificacao | \e606
ico-alert-t | \e64a | ico-alerta-t | \e605
ico-arrow-down | \e688 | -- | --
ico-arrow-left | \e68a | ico-voltar | \e615
ico-arrow-right | \e689 | ico-avancar | \e614
ico-arrow-up | \e687 | -- | --
ico-arrow-triple-left | \e902 | -- | --
ico-bag | \e61e | ico-mala | \e662
ico-bag-medical  | \e695 | -- | --
ico-badge-militar  | \e6a2 | -- | --
ico-band-aid  | \e696 | -- | --
ico-bell | \e632 | ico-pendencias | \f0f3
ico-bell-minus | \e634 | -- | --
ico-bell-plus | \e633 | -- | --
ico-binoculars | \e66e | ico-binoculos | \e622
ico-black-white-c | \e67a | ico-contraste | \e670
ico-bookmark | \e64f | ico-marca | \e66c
ico-bookmarks | \e650 | ico-marcas | \e66d
ico-bookshelf  | \e693 | -- | --
ico-br-gov-mps | \e619 | ico-prevlogo | \e643
ico-brightness | \e678 | ico-brilho | \e66e
ico-bug | \e682 | ico-bug | \e62f
ico-building | \e61b | ico-predio | \e61a
ico-building-arrow | \e913 | -- | --
ico-building-greek | \e61d | ico-biblioteca | \e62d
ico-calendar | \e652 | ico-agendar | \f073
ico-calendar-empty | \e653 | ico-cancelar-agenda | \f133
ico-camera | \e67b | ico-camera | \e62c
ico-cancel | \e640 | ico-cancelar | \e613
ico-cancel-circle | \e912 | -- | --
ico-card | \e91e | -- | --
ico-carret-down | \e921 | -- | --
ico-carret-left | \e923 | -- | --
ico-carret-left-double | \e925 | -- | --
ico-carret-right | \e922 | -- | --
ico-carret-right-double | \e924 | -- | --
ico-carret-up | \e920 | -- | --
ico-check | \e656 | ico-checkbox-checked | \e630
ico-check-circle | \e911 | -- | --
ico-check-mid | \e655 | ico-checkbox-partial | \e632
ico-clip | \e665 | ico-anexo | \e65d
ico-clipboard-check | \e694 | ico-resumir | \e62b
ico-clipboard-list  | \e691 | -- | --
ico-clipboard-man  | \e906 | -- | --
ico-clipboard-pulse  | \e692 | -- | --
ico-clipboard-search | \e926 | -- | --
ico-clock | \e65a | ico-relogio | \e623
ico-cloud | \e662 | ico-nuvem | \e651
ico-cloud-down | \e663 | ico-download | \e652
ico-cloud-up | \e664 | ico-upload | \e653
ico-confirm | \e641 | ico-confirmar | \e668
ico-contrast | \e679 | ico-brilho-contrast | \e66f
ico-counterclockwise | \e65c | -- | --
ico-database | \e931 | -- | --
ico-doc-alert | \e608 | -- | --
ico-doc-arrow-right | \e60a | -- | --
ico-doc-book | \e915 | -- | --
ico-doc-braces | \e610 | ico-css | \e63b
ico-doc-certificate | \e609 | -- | --
ico-doc-check | \e606 | -- | --
ico-doc-check-ci | \e905 | -- | --
ico-doc-code | \e60f | ico-xml | \e63a
ico-doc-copy | \e612 | ico-copiar | \e61b
ico-doc-download | \e914 | -- | --
ico-doc-info | \e904 | -- | --
ico-doc-list | \e600 | ico-doc | \e655
ico-doc-magnifier | \e605 | ico-analisar | \e617
ico-doc-minus | \e603 | ico-docsubtrair | \e654
ico-doc-pdf | \e60b | ico-pdf | \e636
ico-doc-pencil | \e601 | ico-req-alterar | \e661
ico-doc-plus | \e602 | ico-docadicionar | \e629
ico-doc-presentation | \e60e | ico-powerpoint | \e639
ico-doc-question | \e607 | -- | --
ico-doc-refresh | \e604 | ico-atualizacao | \e665
ico-doc-refresh-29 | \e907 | -- | --
ico-doc-sheet | \e60c | ico-excel | \e637
ico-doc-thumb-down | \e900 | -- | --
ico-doc-thumb-up | \e901 | -- | --
ico-doc-zip | \e60d | ico-zip | \e638
ico-docs | \e611 | ico-docs | \e656
ico-docs-archive | \e616 | ico-arquivamento | \e650
ico-docs-drawer | \e615 | ico-abrirreq | \e60b
ico-docs-layer | \e613 | ico-pilha | \e61e
ico-door-in | \e669 | ico-entrar | \e647
ico-door-out | \e66a | ico-sair | \e648
ico-down-c | \e68c | ico-mostrar | \e60c
ico-download | \e90f | -- | --
ico-expand | \e927 | -- | --
ico-eye | \e66f | ico-detalhar | \e611
ico-eye-no | \e670 | ico-cancel-detalhar | \e612
ico-flag | \e651 | ico-bandeira | \e66b
ico-floppy-disk | \e646 | ico-salvar | \e61f
ico-folder | \e617 | -- | --
ico-folder-open | \e618 | ico-pasta | \e660
ico-funnel | \e66b | ico-filtro | \e658
ico-gauge | \e621 | ico-dashboard | \e625
ico-gear | \e66c | ico-conf | \e604
ico-graph-line | \e622 | ico-graf | \e65a
ico-graph-pizza | \e623 | ico-pizza | \e659
ico-hammer | \e62f | ico-martelo | \e626
ico-hammer-base | \e916 | -- | --
ico-hammer-base-minus | \e918 | -- | --
ico-hammer-base-plus | \e917 | -- | --
ico-handshake | \e90d | -- | --
ico-help-c | \e64e | ico-ajuda | \e607
ico-hourglass | \e65f | ico-ampulheta | \e621
ico-hourglass-end | \e65e | -- | --
ico-hourglass-minus | \e929 | -- | --
ico-hourglass-plus | \e928 | -- | --
ico-hourglass-start | \e65d | -- | --
ico-house | \e61c | ico-home | \e619
ico-image | \e67c | ico-imagem | \e65e
ico-index-card | \e61f | -- | --
ico-info | \e64d | ico-info-n | \f129
ico-info-c | \e64c | ico-info | \e609
ico-jail | \e6a3 | -- | --
ico-key | \e666 | ico-chave | \e62e
ico-keyboard | \e62c | ico-teclado | \e64c
ico-left-c | \e68d | -- | --
ico-left-double-c | \e6a0 | -- | --
ico-letter | \e680 | -- | --
ico-letter-small | \e92a | -- | --
ico-link | \e660 | ico-elo | \e664
ico-link-minus | \e91d | -- | --
ico-link-plus | \e91c | -- | --
ico-lion-face | \e61a | -- | --
ico-lock | \e667 | ico-bloquear | \f023
ico-magnifier | \e66d | ico-pesquisar | \e60f
ico-mail | \e67e | ico-email | \e61d
ico-man | \e63c | ico-homem | \f183
ico-megaphone | \e631 | ico-exigencias | \f0a1
ico-minus | \e63f | ico-subtrair | \e669
ico-money | \e673 | ico-cifrao | \e608
ico-money-bag | \e672 | -- | --
ico-money-c | \e671 | ico-moeda | \e649
ico-money-pencil | \e90e | -- | --
ico-monitor | \e62b | ico-tela | \e64d
ico-more-horizontal | \e674 | ico-generica | \f141
ico-more-vertical | \e675 | -- | --
ico-pacifier | \e92b | -- | --
ico-pencil | \e642 | ico-alterar | \e60e
ico-phone | \e628 | ico-fone | \e620
ico-pin | \e908 | -- | --
ico-pj-check | \e919 | -- | --
ico-plug | \e62e | ico-plugin | \e645
ico-plus | \e63e | ico-adicionar | \e66a
ico-print | \e648 | ico-imprimir | \f02f
ico-process-check | \e91a | -- | --
ico-radio | \e658 | ico-radio-checked | \e633
ico-radioactive-c  | \e698 | -- | --
ico-ray | \e647 | ico-raio | \e627
ico-right-c | \e68e | -- | --
ico-right-double-c | \e6a1 | -- | --
ico-route | \e909 | -- | --
ico-school-cap | \e903 | -- | --
ico-seal | \e645 | ico-comprovar | \e618
ico-seals | \e90c | -- | --
ico-seals-minus | \e90b | -- | --
ico-seals-plus | \e90a | -- | --
ico-serving-man | \e620 | -- | --
ico-shield | \e676 | ico-escudo | \e628
ico-shield-user | \e92c | -- | --
ico-ship | \e627 | -- | --
ico-sigma | \e67f | ico-somatorio | \e65b
ico-smartphone | \e629 | ico-celular | \e64e
ico-spinner | \e659 | ico-spinner | \e624
ico-stamp | \e644 | ico-homologar | \e616
ico-star | \e92d | -- | --
ico-star-empty | \e92e | -- | --
ico-star-of-life  | \e697 | -- | --
ico-stethoscope | \e690 | -- | --
ico-tablet | \e62a | ico-tablet | \e64f
ico-terminal | \e62d | ico-terminal | \e65c
ico-text-size | \e681 | -- | --
ico-thermometer  | \e69c | -- | --
ico-thumb-down  | \e6a4 | -- | --
ico-thumb-up  | \e6a5 | -- | --
ico-ticket | \e92f | -- | --
ico-tickets | \e930 | -- | --
ico-timemachine | \e65b | ico-historico | \e60a
ico-tractor | \e624 | ico-trator | \e644
ico-traffic-light | \e677 | ico-permissao | \e657
ico-transfer | \e68f | ico-transferencia | \f0ec
ico-trash-can | \e643 | ico-excluir | \e610
ico-trash-can-recover | \e91b | -- | --
ico-triangle-left2 | \e614 | -- | --
ico-triangle-right2 | \e69d | -- | --
ico-triangle-first | \e69e | -- | --
ico-triangle-last | \e69f | -- | --
ico-triangle-down | \e684 | ico-caret-baixo | \f0d7
ico-triangle-left | \e686 | ico-caret-esquerda | \f0d9
ico-triangle-right | \e685 | ico-caret-direita | \f0da
ico-triangle-up | \e683 | ico-caret-cima | \f0d8
ico-truck | \e625 | ico-atividades | \e663
ico-uncheck | \e654 | ico-checkbox-unchecked | \e631
ico-unlink | \e661 | -- | --
ico-unlock | \e668 | ico-desbloquear | \f09c
ico-unradio | \e657 | ico-radio-unchecked | \e634
ico-up-c | \e68b | ico-esconder | \e60d
ico-upload | \e910 | -- | --
ico-user | \e635 | ico-usuario | \e600
ico-user-c | \e636 | -- | --
ico-user-doctor  | \e699 | -- | --
ico-user-indian  | \e91f | -- | --
ico-user-minus | \e638 | -- | --
ico-user-plus | \e637 | ico-add-usuario | \e602
ico-user-profile | \e63a | ico-perfil-usuario | \e603
ico-user-magnifier  | \e69a | -- | --
ico-user-tie  | \e69b | -- | --
ico-users | \e639 | ico-usuarios | \e601
ico-video | \e67d | ico-filme | \e65f
ico-wheelchair | \e63b | ico-cadrodas | \f193
ico-woman | \e63d | ico-mulher | \f182
ico-world | \e630 | ico-terra | \e646

-------------------------------------------------------------------------------